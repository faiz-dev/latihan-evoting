export const API_URL = 'https://pilketosapi.smkn1kandeman.sch.id/'
// export const API_URL = 'http://localhost:5000'