const FooterText = () => {
  return <span className='footer-text font-light'><b className='text-primary font-bold'>evoting</b> by pplgskansaka.com</span>
}

export default FooterText